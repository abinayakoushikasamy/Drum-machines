import "./Box.css";

const Box = ({ children }) => {
  return <div className="Box">{children}</div>;
};

export default Box;