import { createContext } from "react";

const githubContext = createContext();

export default githubContext;