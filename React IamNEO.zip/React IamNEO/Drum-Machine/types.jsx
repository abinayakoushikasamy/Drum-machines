export const POWER_TOGGLE = "POWER_TOGGLE";
export const CHANGE_VOLUME = "CHANGE_VOLUME";
